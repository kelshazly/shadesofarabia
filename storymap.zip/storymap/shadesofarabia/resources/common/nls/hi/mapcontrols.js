define({
  "commonMapControls": {
    "common": {
      "settings": "सेटिंग्स",
      "openDefault": "डिफ़ॉल्ट रूप से खुलता है"
    },
    "overview": {
      "basemapGalleryBtnLabel": "बेसमैप",
      "expandFactorLabel": "विस्तार कारक",
      "expandFactorPopover": "संक्षिप्त मानचित्र के आकार और संक्षिप्त मानचित्र पर प्रदर्शित सीमा आयत के बीच अनुपात। डिफ़ॉल्ट मान 2 होता है, अर्थात संक्षिप्त मानचित्र सीमा आयत के आकार का कम से कम दोगुना होगा।"
    }
  }
});