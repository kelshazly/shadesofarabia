define({
  "commonMapControls": {
    "common": {
      "settings": "설정",
      "openDefault": "기본적으로 열기"
    },
    "overview": {
      "basemapGalleryBtnLabel": "베이스맵",
      "expandFactorLabel": "확장 계수",
      "expandFactorPopover": "개요 맵과 개요 맵에 표시되는 범위 사각형 간의 크기 비율입니다. 기본값은 2입니다. 이는 개요 맵이 범위 사각형보다 최소 2배 더 크다는 의미입니다."
    }
  }
});