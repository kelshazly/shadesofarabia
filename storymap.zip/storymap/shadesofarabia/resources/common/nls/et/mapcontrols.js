define({
  "commonMapControls": {
    "common": {
      "settings": "Seaded",
      "openDefault": "Vaikimisi avatud"
    },
    "overview": {
      "basemapGalleryBtnLabel": "Aluskaart",
      "expandFactorLabel": "Laiendamise faktor",
      "expandFactorPopover": "Ülevaatekaardi ja ülevaatekaardil kuvatava ulatuse ristküliku suuruse suhe. Vaikeväärtus on 2, mis tähendab, et ülevaatekaart on ulatuse ristkülikust vähemalt kaks korda suurem."
    }
  }
});