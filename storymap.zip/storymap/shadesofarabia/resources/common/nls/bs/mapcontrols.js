define({
  "commonMapControls": {
    "common": {
      "settings": "Postavke",
      "openDefault": "Otvori prema zadanim postavkama"
    },
    "overview": {
      "basemapGalleryBtnLabel": "Kartografska podloga",
      "expandFactorLabel": "Omjer širenja",
      "expandFactorPopover": "Odnos između veličine pregledne karte i pravokutnika obuhvata prikazanog na preglednoj karti. Zadana vrijednost je 2, što znači da je pregledna karta barem dvaput veća od pravokutnika obuhvata."
    }
  }
});