define({
  "commonMapControls": {
    "common": {
      "settings": "الإعدادات",
      "openDefault": "الفتح افتراضيًا"
    },
    "overview": {
      "basemapGalleryBtnLabel": "خريطة أساس",
      "expandFactorLabel": "توسيع المعامل",
      "expandFactorPopover": "النسبة بين حجم خريطة النظرة العامة ومستطيل النطاق المعروض على خريطة النظرة العامة. تكون القيمة الافتراضية 2، هذا يعني أن خريطة النظرة العامة ستكون ضعف حجم مستطيل النطاق على الأقل."
    }
  }
});