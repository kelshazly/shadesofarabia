define({
  "commonMapControls": {
    "common": {
      "settings": "Ustawienia",
      "openDefault": "Otwieraj domyślnie"
    },
    "overview": {
      "basemapGalleryBtnLabel": "Mapa bazowa",
      "expandFactorLabel": "Współczynnik powiększenia obrazu",
      "expandFactorPopover": "Stosunek wielkości mapy przeglądowej do pola zasięgu wyświetlanego na mapie przeglądowej. Domyślna wartość to 2, co oznacza, że mapa przeglądowa będzie przynajmniej dwa razy większa od pola zasięgu."
    }
  }
});